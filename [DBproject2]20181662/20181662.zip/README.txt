1. mysql.h의 include 및 lib 경로 설정 시 제대로 작동하지 않아, 임의로 제 PC 내의 include 및 lib path에 파일을 직접 추가하였습니다. 이를 위해 이용한 SDK 버전은 10.0.16299.0 입니다. 

2. CRUD를 위한 txt 파일을 두개로 구성하였으며, 20181662_ci.txt는 create 및 insert를, 20181662_dd.txt는 delete 및 drop을 수행합니다. 

3. 제 PC의 3306 포트가 제대로 작동하지 않아 코드 내의 포트를 3305로 변경하여 프로젝트를 진행했습니다. 

4. libmysql.dll 및 libmysql.lib 파일을 폴더 내에 포함시켜야 정상적으로 작동하는 것을 확인했습니다. 

감사합니다. 