#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "mysql.h"
#include <stdlib.h>

#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "root";
const char* pw = "dndud12#45";
const char* db = "project";

int main(void) {

	MYSQL* connection = NULL;
	MYSQL conn;
	MYSQL_RES* sql_result;
	MYSQL_ROW sql_row;

	char* buffer = NULL;
	long long int size;

	/* read query for create & insert data */
	FILE* fp = fopen("20181662_ci.txt", "r");
	fseek(fp, 0, SEEK_END);
	size = ftell(fp);
	buffer = (char*)malloc(size + 1);
	memset(buffer, 0, size + 1);
	fseek(fp, 0, SEEK_SET);
	fread(buffer, size, 1, fp);


	if (mysql_init(&conn) == NULL)
		printf("mysql_init() error!");

	connection = mysql_real_connect(&conn, host, user, pw, db, 3305, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}

	else
	{
		printf("Connection Succeed\n");

		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}
		
		char query[2048];
		int state = 0;
		const char* temp = strtok(buffer, ";");
		while (temp != NULL) {
			state = 0;
			state = mysql_query(connection, temp);
			temp = strtok(NULL, ";");
		}
		int isstop = 0;
		int type; int subtype; int k;
		int numRow = 0;
		while (1) {
			isstop = 0;
			printf("\n\n------- SELECT QUERY TYPES -------\n\n");
			printf("\t1. TYPE 1\n");
			printf("\t2. TYPE 2\n");
			printf("\t3. TYPE 3\n");
			printf("\t4. TYPE 4\n");
			printf("\t5. TYPE 5\n");
			printf("\t6. TYPE 6\n");
			printf("\t7. TYPE 7\n");
			printf("\t0. QUIT\n");
			printf("----------------------------------\n");
			printf("Select Number : ");
			scanf(" %d", &type);
			getchar();
			switch (type) {
			case 1:
				printf("\n\n");
				printf("---- TYPE 1 ----\n\n");
				printf("** with traking number X **\n");
				printf(" Which X? : ");
				scanf(" %d", &k);
				getchar();
				memset(query, 0, sizeof(query));
				sprintf(query, "select customer_phone, customer_name, customer_ID, customer_address from shipment natural join sales natural join customer where shipping_number = %d and shipping_company = \"USPS\"; ", k);
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\ncustomer_phone  customer_name  customer_ID  customer_address\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s  %-5s  %-5s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");
				printf("---- Subtypes in TYPE 1 ----\n");
				printf("\t1. TYPE 1-1\n");
				printf("\t0. QUIT\n");
				printf("----------------------------\n");
				printf("Select Number : ");
				scanf(" %d", &subtype);
				if (subtype != 1) break;

				printf("\n---- TYPE 1-1 ----\n\n");
				printf("\n shipment data \n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select * from shipment where shipping_number = %d", k);
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\nsales_ID  shipping_number  shipping_company  delivery_date\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s  %-5s  %-5s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
					}
					mysql_free_result(sql_result);
				}
				memset(query, 0, sizeof(query));
				sprintf(query, "update shipment SET delivery_date = delivery_date + 7 where shipping_number = %d and shipping_company = \"USPS\";", k);
				state = 0;
				state = mysql_query(connection, query);
				printf("\n Delivery date postponed by 1 week. \n");
				sql_result = mysql_store_result(connection);
				mysql_free_result(sql_result);
				memset(query, 0, sizeof(query));
				break;

			case 2:
				printf("\n\n");
				printf("---- TYPE 2 ----\n\n");
				printf(" customer who has bought the most (by price) in the past year.\n");
				char mostID[20];
				memset(query, 0, sizeof(query));
				sprintf(query, "select customer_ID, customer_name, sum(total_price) from sales natural join customer where year(sales_date) = 2021 group by customer_ID order by sum(total_price) desc limit 1;");
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\ncustomer_ID  customer_name  sum of total_price\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s  %-5s\n", sql_row[0], sql_row[1], sql_row[2]);
						memcpy(mostID, sql_row[0], sizeof(sql_row[0]));
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");
				printf("---- Subtypes in TYPE 2 ----\n");
				printf("\t1. TYPE 2-1\n");
				printf("\t0. QUIT\n");
				printf("----------------------------\n");
				printf("Select Number : ");
				scanf(" %d", &subtype);
				if (subtype != 1) break;

				printf("\n---- TYPE 2-1 ----\n\n");
				printf(" product that the customer bought the most\n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select prod_ID, sum(order_amount) as amount from sales natural join ordered where customer_ID = \"%s\" group by prod_ID order by amount desc limit 1;", mostID);
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\nprod_ID  amount\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s\n", sql_row[0], sql_row[1]);
					}
					mysql_free_result(sql_result);
				}
				break;

			case 3:
				printf("\n\n");
				numRow = 0;
				printf("---- TYPE 3 ----\n\n");
				printf(" all products sold in the past year\n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select prod_ID, prod_price, order_amount, sum((prod_price * order_amount)) from sales natural join ordered natural join product where year(sales_date) = 2021 group by prod_ID order by prod_ID asc;");
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\nprod_ID  dollar amount\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						numRow++;
						printf("%-5s  %-5s\n", sql_row[0], sql_row[3]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");

				printf("---- Subtypes in TYPE 3 ----\n");
				printf("\t1. TYPE 3-1\n");
				printf("\t2. TYPE 3-2\n");
				printf("\t0. QUIT\n");
				printf("----------------------------\n");
				printf("Select Number : ");
				scanf(" %d", &subtype);
				if (subtype == 1) {
					printf("---- TYPE 3-1 ----\n\n");
					printf("** Then find the top k products by dollar **");
					printf("\nWhich k? : ");
					scanf(" %d", &k);
					memset(query, 0, sizeof(query));
					sprintf(query, "select prod_ID, prod_price, order_amount, sum((prod_price * order_amount)) as k from sales natural join ordered natural join product where year(sales_date) = 2021 group by prod_ID order by k desc limit %d;", k);
					state = 0;
					state = mysql_query(connection, query);
					if (state == 0) {
						printf("\nprod_ID  dollar amount\n");
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
							printf("%-5s  %-5s\n", sql_row[0], sql_row[3]);
						}
						mysql_free_result(sql_result);
					}
				}
				else if (subtype == 2) {
					printf("---- TYPE 3-2 ----\n\n");
					printf("** Then find the top 10%% products by dollar **");
					k = numRow / 10;
					if (k == 0) k++;
					memset(query, 0, sizeof(query));
					sprintf(query, "select prod_ID, prod_price, order_amount, sum((prod_price * order_amount)) as k from sales natural join ordered natural join product where year(sales_date) = 2021 group by prod_ID order by k desc limit %d;", k);
					state = 0;
					state = mysql_query(connection, query);
					if (state == 0) {
						printf("\nprod_ID  dollar amount\n");
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
							printf("%-5s  %-5s\n", sql_row[0], sql_row[3]);
						}
						mysql_free_result(sql_result);
					}
				}
				break;

			case 4:
				printf("\n\n");
				numRow = 0;
				printf("---- TYPE 4 ----\n\n");
				printf(" all products sold in the past year\n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select prod_ID,  sum(order_amount) from sales natural join ordered natural join product where year(sales_date) = 2021 group by prod_ID order by prod_ID desc;");
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\nprod_ID  amount\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						numRow++;
						printf("%-5s  %-5s\n", sql_row[0], sql_row[1]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");

				printf("---- Subtypes in TYPE 4 ----\n");
				printf("\t1. TYPE 4-1\n");
				printf("\t2. TYPE 4-2\n");
				printf("\t0. QUIT\n");
				printf("----------------------------\n");
				printf("Select Number : ");
				scanf(" %d", &subtype);
				if (subtype == 1) {
					printf("---- TYPE 4-1 ----\n\n");
					printf("** Then find the top k products by unit **");
					printf("\nWhich k? : ");
					scanf(" %d", &k);
					memset(query, 0, sizeof(query));
					sprintf(query, "select prod_ID,  sum(order_amount) as k from sales natural join ordered natural join product where year(sales_date) = 2021 group by prod_ID order by k desc limit %d;", k);
					state = 0;
					state = mysql_query(connection, query);
					if (state == 0) {
						printf("\nprod_ID  amount\n");
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
							printf("%-5s  %-5s\n", sql_row[0], sql_row[1]);
						}
						mysql_free_result(sql_result);
					}
				}
				else if (subtype == 2) {
					printf("---- TYPE 4-2 ----\n\n");
					printf("** Then find the top 10%% products by unit **");
					k = numRow / 10;
					if (k == 0) k++;
					memset(query, 0, sizeof(query));
					sprintf(query, "select prod_ID,  sum(order_amount) as k from sales natural join ordered natural join product where year(sales_date) = 2021 group by prod_ID order by k desc limit %d;", k);
					state = 0;
					state = mysql_query(connection, query);
					if (state == 0) {
						printf("\nprod_ID  amount\n");
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
							printf("%-5s  %-5s\n", sql_row[0], sql_row[1]);
						}
						mysql_free_result(sql_result);
					}
				}
				break;

			case 5:
				printf("\n\n");
				printf("---- TYPE 5 ----\n\n");
				printf("products that are out of stock at every store in California\n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select prod_ID, inven_amount from inventory natural join store where store_address = \"California\" and inven_amount = 0;");
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\nprod_ID  amount\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s\n", sql_row[0], sql_row[1]);
					}
					mysql_free_result(sql_result);
				}
				break;

			case 6:
				printf("\n\n");
				printf("---- TYPE 6 ----\n\n");
				printf("packages that were not delivered within the promised time\n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select * from shipment where delivery_date < '2022-06-08' and isdelivered = 0");
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\nsales_ID  shipping_number  shipping_company  delivery_date\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s  %-5s  %-5s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
					}
					mysql_free_result(sql_result);
				}
				break;

			case 7:
				printf("\n\n");
				printf("---- TYPE 7 ----\n\n");
				printf("bill for the past month\n");
				memset(query, 0, sizeof(query));
				sprintf(query, "select customer_ID, sum(total_price) as price from sales where year(sales_date) = '2022' and month(sales_date) = '05' group by customer_ID;");
				state = 0;
				state = mysql_query(connection, query);
				if (state == 0) {
					printf("\ncustomer_ID  price\n");
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL) {
						printf("%-5s  %-5s\n", sql_row[0], sql_row[1]);
					}
					mysql_free_result(sql_result);
				}
				break;

			case 0:
				isstop = 1;
				break;
			default:
				isstop = 0;
				break;
			}
			if (isstop) break;
		}
		FILE* fp2 = fopen("20181662_dd.txt", "r");
		char* buffer2 = NULL;

		fseek(fp2, 0, SEEK_END);
		size = ftell(fp2);
		buffer2 = (char*)malloc(size + 1);
		memset(buffer2, 0, size + 1);
		fseek(fp2, 0, SEEK_SET);
		fread(buffer2, size, 1, fp2);

		temp = strtok(buffer2, ";");
		while (temp != NULL) {
			state = 0;
			state = mysql_query(connection, temp);
			temp = strtok(NULL, ";");
		}
		mysql_close(connection);
		fclose(fp2);
		free(buffer2);
	}
	fclose(fp);
	free(buffer);

	return 0;
}





